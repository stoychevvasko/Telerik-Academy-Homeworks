﻿define(function () {
    return [
        { id: 1, name: "Doncho Minkov", age: 18, avatarUrl: "../../resources/images/minkov.jpg" },
        { id: 2, name: "Todor Stoyanov", age: 19, avatarUrl: "../../resources/images/todor.jpg" },
        { id: 3, name: "Nikolay Kostov", age: 18, avatarUrl: "../../resources/images/niki.jpg" },
        { id: 4, name: "Ivaylo Kenov", age: 19, avatarUrl: "../../resources/images/ivo.jpg" }
    ];
});