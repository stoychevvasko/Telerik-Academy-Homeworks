﻿var allHomeworkTasks = [
    {
        'number': 1,
        'description': '<div><p>Create a module for working with DOM. The module should have the following functionality</p><ul><li>Add DOM element to parent element given by selector</li><li>Remove element from the DOM  by given selector</li><li>Attach event to given selector by given event type and event hander</li><li>Add elements to buffer, which appends them to the DOM when their count for some selector becomes 100</li><li>The buffer contains elements for each selector it gets</li><li>Get elements by CSS selector</li><li>The module should reveal only the methods</li></ul></div>',
        'link': 'solutions/task-01/task-01.html'
    },
    {
        'number': 2,
        'description': '<div>Create a module that works with moving div nodes. Implement functionality for:<ul><li>Add new moving div element to the DOM<ul><li>The module should generate random background, font and border colors for the div element</li><li>All the div elements are with the same width and height</li></ul></li><li>The movements of the div nodes can be either circular or rectangular</li><li>The elements should be moving all the time</li></ul></div>',
        'link': 'solutions/task-02/task-02.html'
    },
    {
        'number': 3,
        'description': '<div>Create a module to work with the console object.Implement functionality for:<ul><li>Writing a line to the console</li><li>Writing a line to the console using a format</li><li>Writing to the console should call toString() to each element</li><li>Writing errors and warnings to the console with and without format</li></ul></div>',
        'link': 'solutions/task-03/task-03.html'
    }
];

var allBoxImages = [
    'resources/images/keyboard-glow.jpg',
    'resources/images/circuit-board.jpg',
    'resources/images/computer-code.jpg',
    'resources/images/cloud-computing.jpg',
    'resources/images/fiber-optics.jpg',
    'resources/images/circuit-brain.jpg',
    'resources/images/global-internet.jpg',
    'resources/images/shared-web.jpg',
    'resources/images/apps-globe.jpg',
]
