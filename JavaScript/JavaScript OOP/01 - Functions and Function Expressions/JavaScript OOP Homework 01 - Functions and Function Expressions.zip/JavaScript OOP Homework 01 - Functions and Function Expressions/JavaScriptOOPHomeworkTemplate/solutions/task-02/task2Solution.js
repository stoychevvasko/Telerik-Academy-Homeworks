﻿var randomDivModule = (function () {
    var rectangularMotionDivs = [],
        circularMotionDivs = [];

    function addRectangularMotionDiv() {
        var newMovingDiv = createRandomDiv();
        rectangularMotionDivs.push(newMovingDiv);
        $('#wrapper').append(newMovingDiv);
    }

    function addCircularMotionDiv() {
        var newMovingDiv = createRandomDiv();
        circularMotionDivs.push(newMovingDiv);
        $('#wrapper').append(newMovingDiv);
    }

    function moveAllDivs() {
        moveDivsInCircles();
        moveDivsInRectangles();
    }

    return {
        addRectangularMotionDiv: addRectangularMotionDiv,
        addCircularMotionDiv: addCircularMotionDiv,
        moveAllDivs: moveAllDivs,
    }

    function createRandomDiv() {
        var div = document.createElement('div');

        div.style.height = 66;
        div.style.width = 66;
        div.style.position = 'absolute';
        div.style.left = Math.floor((Math.random() * 690)) + 'px';
        div.style.top = Math.floor((Math.random() * 340) + 65) + 'px';

        div.style.backgroundColor = randomColor();
        div.style.color = randomColor();
        div.style.borderRadius = '1px';
        div.style.border = '3px solid ' + randomColor();

        div.innerHTML = '<strong>div</strong>';

        return div;
    }

    function randomColor() {
        var red = Math.floor((Math.random() * 255) + 1),
            green = Math.floor((Math.random() * 255) + 1),
            blue = Math.floor((Math.random() * 255) + 1);

        return 'rgb(' + red + ', ' + green + ', ' + blue + ')';
    }

    function moveDivsInCircles() {
        var radius = 10,
            angle = 0;

        var functionTimer = setInterval(function moveDivs() {
            angle -= 2;
            if (angle <= 0) {
                angle = 360;
            }
            
            for (var i = 0; i < circularMotionDivs.length; i += 1) {
                var rect = circularMotionDivs[i].getBoundingClientRect();

                var centerX = (rect.right - rect.left) / 2.0;
                var centerY = (rect.top - rect.bottom) / 2.0;

                var left = centerX + Math.cos((2 * 3.14 / 180) * angle) * radius;
                var right = centerY + Math.sin((2 * 3.14 / 180) * angle) * radius;

                circularMotionDivs[i].style.left = left + 'px';
                circularMotionDivs[i].style.top = right + 'px';
            }
        }, 10);
    }

    function moveDivsInRectangles() {

    }
})();

$(document).ready(function () {
    (function () {
        var buttonCircularDiv = document.getElementById('add-circular-motion-div'),
            buttonRectangularDiv = document.getElementById('add-rectangular-motion-div');

        buttonCircularDiv.addEventListener('click', function () {
            randomDivModule.addCircularMotionDiv();
        });

        buttonRectangularDiv.addEventListener('click', function () {
            randomDivModule.addRectangularMotionDiv();
        });

        randomDivModule.moveAllDivs();
    }());
});


