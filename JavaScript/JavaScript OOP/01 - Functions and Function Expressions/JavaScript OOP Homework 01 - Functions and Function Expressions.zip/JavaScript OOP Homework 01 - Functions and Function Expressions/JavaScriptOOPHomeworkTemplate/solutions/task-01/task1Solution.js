﻿var domModule = (function () {
    var MAX_BUFFER_SIZE = 100;
    var buffer = [];

    function appendChild(childElement, parentSelector) {
        var parent = document.querySelector(parentSelector);
        parent.appendChild(childElement);
    }

    function removeChild(parentSelector, childSelector) {
        var parent = document.querySelector(parentSelector);
        var child = parent.querySelector(childSelector);
        parent.removeChild(child);
    }

    function addHandler(selector, eventType, eventHandler) {
        var elements = document.querySelectorAll(selector);
        var i;        
        for (i = 0; i < elements.length; i += 1) {
            elements[i].addEventListener(eventType, eventHandler);
        }
    }

    function addToBuffer(parentSelector, childElement) {
        var parent = document.querySelector(parentSelector);
        if (!buffer[parent]) {
            buffer[parent] = document.createDocumentFragment();
        }

        buffer[parent].appendChild(childElement);

        if (buffer[parent].childElementCount === MAX_BUFFER_SIZE) {
            parent.appendChild(buffer[parent]);
        }
    }

    function getElementBySelector(selector) {
        return document.querySelector(selector);
    }

    function getAllElementsBySelector(selector) {
        return document.querySelectorAll(selector);
    }

    return {
        appendChild: appendChild,
        removeChild: removeChild,
        addHandler: addHandler,
        addToBuffer: addToBuffer,
        getElementBySelector: getElementBySelector,
        getAllElementsBySelector: getAllElementsBySelector
    }
})();

function getElementType(element) {
    if (element === null) return "[object Null]";
    return Object.prototype.toString.call(element);
}