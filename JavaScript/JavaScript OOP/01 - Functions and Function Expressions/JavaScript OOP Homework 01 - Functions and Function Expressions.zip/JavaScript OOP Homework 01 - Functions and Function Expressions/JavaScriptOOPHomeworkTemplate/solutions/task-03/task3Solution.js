﻿var consoleModule = (function () {
    function writeLine(parameter) {
        console.log(parameter);
    }

    return {
        writeLine: writeLine,
    }
})();

$(document).ready(function () {
    (function () {
        $('div#wrapper #writeLine-submit-button').click(function () {
            document.getElementById('buzz').play();
            consoleModule.writeLine($('div#wrapper #writeLine-text-input').val());
        });

        $('div#wrapper #writeLine2-submit-button').click(function () {
            document.getElementById('buzz').play();
            
        });

        $('div#wrapper #writeError-submit-button').click(function () {
            document.getElementById('buzz').play();
        });

        $('div#wrapper #writeWarning-submit-button').click(function () {
            document.getElementById('buzz').play();
        });

        consoleModule.writeLine("Message: hello");
        //logs to the console "Message: hello"
        consoleModule.writeLine("Message: {0}", "hello");
        //logs to the console "Message: hello"
        //consoleModule.writeError("Error: {0}", "Something happened");
        //consoleModule.writeWarning("Warning: {0}", "A warning");

    }());
});


