﻿var allHomeworkTasks = [
    {
        'number': 1,
        'description': '<div>Create a module for drawing shapes using Canvas. Implement the following shapes:<ul><li>Rect, by given position (X, Y) and size (Width, Height)</li><li>Circle, by given center position (X, Y) and radius (R)</li><li>Line, by given from (X1, Y1) and to (X2, Y2) positions</li></ul></div>',
        'link': 'solutions/task-01/task-01.html'
    },   
];

var allBoxImages = [
    'resources/images/keyboard-glow.jpg',
    'resources/images/circuit-board.jpg',
    'resources/images/computer-code.jpg',
    'resources/images/cloud-computing.jpg',
    'resources/images/fiber-optics.jpg',
    'resources/images/circuit-brain.jpg',
    'resources/images/global-internet.jpg',
    'resources/images/shared-web.jpg',
    'resources/images/apps-globe.jpg',
]
