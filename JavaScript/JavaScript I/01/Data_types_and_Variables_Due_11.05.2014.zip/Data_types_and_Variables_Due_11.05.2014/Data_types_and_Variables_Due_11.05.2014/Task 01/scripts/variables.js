﻿/// 1. Assign all the possible JavaScript literals to different variables.

console.log('Task 01 Solution');
console.log();

var booleanVar = true;
console.log('booleanVar = ' + booleanVar);

var intVar = 5;
console.log('intVar = ' + intVar);

var floatingPointVar = Math.PI;
console.log('floatingPointVar = ' + floatingPointVar);

var floatingPointScientificVar = 2E-12;
console.log('floatingPointScientificVar = ' + floatingPointScientificVar);

var stringVar = 'abcde';
console.log('stringVar = ' + stringVar);

var arrayVar = [1, 2, 3, 4, 5];
console.log('arrayVar = ' + arrayVar);