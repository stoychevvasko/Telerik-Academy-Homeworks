﻿/// 4. Create null, undefined variables and try typeof on them.

console.log('Task 04 Solution');
console.log();

var undefinedVar;
console.log('undefinedVar = "' + undefinedVar + '" is of ' + typeof (undefinedVar) + ' data type');

var nullVar = null;
console.log('nullVar = "' + nullVar + '" is of ' + typeof (nullVar) + ' data type');