﻿/// 3. Try typeof on all variables you created.

console.log('Task 03 Solution');
console.log();

var booleanVar = true;
console.log('booleanVar = "' + booleanVar + '" is of ' + typeof (booleanVar) + ' data type');

var intVar = 5;
console.log('intVar = "' + intVar + '" is of ' + typeof (intVar) + ' data type');

var floatingPointVar = Math.PI;
console.log('floatingPointVar = "' + floatingPointVar + '" is of ' + typeof (floatingPointVar) + ' data type');

var floatingPointScientificVar = 2E-12;
console.log('floatingPointScientificVar = "' + floatingPointScientificVar + '" is of ' + typeof (floatingPointScientificVar) + ' data type');

var stringVar = 'abcde';
console.log('stringVar = "' + stringVar + '" is of ' + typeof (stringVar) + ' data type');

var undefinedVar;
console.log('undefinedVar = "' + undefinedVar + '" is of ' + typeof (undefinedVar) + ' data type');

var nullVar = null;
console.log('nullVar = "' + nullVar + '" is of ' + typeof (nullVar) + ' data type');

var arrayVar = [1, 2, 3, 4, 5];
console.log('arrayVar = "' + arrayVar + '" is of ' + typeof (arrayVar) + ' data type');
console.log('');

