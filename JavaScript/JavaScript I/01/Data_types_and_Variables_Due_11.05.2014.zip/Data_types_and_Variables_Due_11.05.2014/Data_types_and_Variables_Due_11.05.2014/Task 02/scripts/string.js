﻿/// 2. Create a string variable with quoted text in it. For example: 'How you doin'?', Joey said.

console.log('Task 02 Solution');
console.log();

var stringVar = "'How you doin'?', Joey said.";
console.log("stringVar = " + stringVar);