﻿/// 3. Write an expression that calculates rectangle’s area by given width and height.

console.log('Task 03 Solution\n');

var width = 15.15;
var height = 16.16;

var area = width * height;

console.log('Rectangle area: ' + width + ' * ' + height + ' = ' + area);