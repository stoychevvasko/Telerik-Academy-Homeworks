﻿/// 1. Write an expression that checks if given integer is odd or even.

console.log('Task 01 Solution\n');

for (var i = 1; i < 11; i++) {
    if (i % 2 == 0) {
        console.log(i + " is even.");
    }
    else {
        console.log(i + " is odd.");
    }
}