﻿namespace _03.VariousAnimals
{
    interface ISound
    {
        void MakeSound();
    }
}
