﻿namespace _01.DefineClassStudent
{
    public enum Specialties
    {
        Mathematics,
        Physics,
        Art,
        Philosophy,
        Politics,
        Law,
        Medicine,
        Chemistry,
        DefaultSpecialty
    }
}
