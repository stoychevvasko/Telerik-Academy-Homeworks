﻿namespace _03.ImplementIComparable
{
    public enum Universities
    {
        SofiaUniversity,
        NewBulgarianUniversity,
        PlovdivUniversity,
        TechnicalUniversity,
        UniversityofNationalAndWorldEconomy,
        DefaultUniversity
    }
}
