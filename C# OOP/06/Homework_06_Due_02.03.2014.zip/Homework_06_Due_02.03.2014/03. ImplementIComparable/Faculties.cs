﻿namespace _03.ImplementIComparable
{
    public enum Faculties
    {
        FacultyOfMathematicsAndInformatics,
        FacultyOfClassicalAndNewPhilologies,
        HistoricalFaculty,
        LawFaculty,
        PhilosophicalFaculty,
        EconomicFaculty,
        BiologicalFaculty,
        MedicalFaculty,
        FacultyOfGeologyAndGeography,
        DefaultFaculty
    }
}
