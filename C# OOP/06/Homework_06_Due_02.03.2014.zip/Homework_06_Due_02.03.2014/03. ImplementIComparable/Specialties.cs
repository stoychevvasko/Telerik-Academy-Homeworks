﻿namespace _03.ImplementIComparable
{
    public enum Specialties
    {
        Mathematics,
        Physics,
        Art,
        Philosophy,
        Politics,
        Law,
        Medicine,
        Chemistry,
        DefaultSpecialty
    }
}
