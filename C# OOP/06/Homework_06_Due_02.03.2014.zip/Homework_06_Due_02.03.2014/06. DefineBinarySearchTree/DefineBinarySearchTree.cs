﻿/*

<Problem 06*> 
 
 Define the data structure binary search tree with
 operations for "adding new element", "searching
 element", and "deleting elements". It is not 
 necessary to keep the tree balanced. Implement the
 stabdard methods from System.Object - 
 ToString(), Equals(...), GetHashCode() and the
 operators for comparison == and !=. Add and
 implement the ICloneable interface for deep copy
 of the tree. Remark: Use two types - structure
 BinarySearchTree (for the tree) and class
 TreeNode (for the tree elements). Implement
 IEnumerable<T> to traverse the tree.
 
*/

namespace _06.DefineBinarySearchTree
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class DefineBinarySearchTree
    {
        static void Main()
        {
            
        }
    }
}
