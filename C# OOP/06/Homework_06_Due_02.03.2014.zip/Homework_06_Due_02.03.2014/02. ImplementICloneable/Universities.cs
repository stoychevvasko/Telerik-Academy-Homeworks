﻿namespace _02.ImplementICloneable
{
    public enum Universities
    {
        SofiaUniversity,
        NewBulgarianUniversity,
        PlovdivUniversity,
        TechnicalUniversity,
        UniversityofNationalAndWorldEconomy,
        DefaultUniversity
    }
}
