﻿namespace _02.Problem02
{
    interface IDepositable
    {
        void Deposit(decimal amount);
    }
}
