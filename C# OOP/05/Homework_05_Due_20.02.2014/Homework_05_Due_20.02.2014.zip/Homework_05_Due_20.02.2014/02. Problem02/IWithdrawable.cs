﻿namespace _02.Problem02
{
    interface IWithdrawable
    {
        void Withdraw(decimal amount);
    }
}
