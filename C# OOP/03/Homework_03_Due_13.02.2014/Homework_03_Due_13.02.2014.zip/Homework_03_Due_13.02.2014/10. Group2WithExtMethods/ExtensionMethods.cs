﻿namespace _10.Group2WithExtMethods
{
    using System.Linq;
    using System.Collections.Generic;
    using _09.CompleteStudentClass;

    public static class ExtensionMethods
    {
        public static List<Student> StudentsInGroup2(this List<Student> sourceList)
        {
            List<Student> result = new List<Student>();

            var linqQuery =
                from student in sourceList
                where student.GroupNumber == 2
                orderby student.FirstName ascending, student.LastName ascending
                select student;

            foreach (var item in linqQuery)
            {
                result.Add(item);
            }

            return result;
        }

    }
}
