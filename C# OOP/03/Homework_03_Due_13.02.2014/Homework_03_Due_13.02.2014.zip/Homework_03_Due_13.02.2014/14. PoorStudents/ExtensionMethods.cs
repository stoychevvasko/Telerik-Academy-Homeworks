﻿namespace _14.PoorStudents
{
    using System;
    using System.Linq;
    using System.Collections.Generic;
    using _09.CompleteStudentClass;   

    public static class ExtensionMethods
    {
        public static List<Student> StudentsWithPoorGrades(this List<Student> sourceList)
        {
            List<Student> result = new List<Student>();

            var linqQuery =
                from student in sourceList
                where student.Marks.Count(x => x == 2) == 2
                select student;

            foreach (var item in linqQuery)
            {
                result.Add(item);
            }

            return result;
        }
    }
}
