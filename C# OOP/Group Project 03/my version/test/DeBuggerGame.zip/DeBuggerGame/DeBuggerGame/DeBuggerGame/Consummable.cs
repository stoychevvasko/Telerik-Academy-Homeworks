﻿namespace DeBuggerGame
{
    public abstract class Consummable
        : Item
    {
        #region constructors

        public Consummable()
            : base()
        {
        }

        #endregion
    }
}
