﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace DeBuggerGame
{
    public abstract class GameObject
    {
        #region constructors

        public GameObject()
        {
        }

        #endregion
    }
}
