﻿namespace DeBuggerGame
{
    using System;
    using Microsoft.Xna.Framework;
    using Microsoft.Xna.Framework.Graphics;

    public class Player
        : Agent
    {
        #region properties

        public bool Active { get; set; }

        #endregion

        
    }
}
