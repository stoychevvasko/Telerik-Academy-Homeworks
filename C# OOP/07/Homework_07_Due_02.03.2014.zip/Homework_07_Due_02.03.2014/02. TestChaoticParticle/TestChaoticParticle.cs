﻿/*

<Problem 02>

 Test the ChaoticParticle through the
 ParticleSystemMain class.
 
*/
namespace _02.TestChaoticParticle
{
    using System;

    class TestChaoticParticle
    {
        static void Main()
        {
            Console.Title = "TestChaoticParticle";
            Console.SetWindowSize(40, 10);
            Console.BufferWidth = Console.WindowWidth = 40;
            Console.BufferHeight = Console.WindowHeight = 10;

            Console.WriteLine("Please go to ParticleSystemMain.cs \nin the ParticleSystem project.");
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
