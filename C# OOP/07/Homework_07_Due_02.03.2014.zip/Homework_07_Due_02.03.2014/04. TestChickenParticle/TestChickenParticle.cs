﻿/*

<Problem 04>

 Test the ChickenParticle class through the
 ParticleSystemMain class.
 
*/
namespace _04.TestChickenParticle
{
    using System;

    class TestChickenParticle
    {
        static void Main()
        {
            Console.Title = "TestChickenParticle";
            Console.SetWindowSize(40, 10);
            Console.BufferWidth = Console.WindowWidth = 40;
            Console.BufferHeight = Console.WindowHeight = 10;

            Console.WriteLine("Please go to ParticleSystemMain.cs \nin the ParticleSystem project.");
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
