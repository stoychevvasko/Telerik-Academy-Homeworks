﻿/*

<Problem 01>

 Create a ChaoticParticle class, which is a Particle,
 randomly changing its movement speed (Speed). You are
 not allowed to edit any existing class.
 
*/
namespace _01.CreateChaoticParticleClass
{
    using System;    

    class CreateChaoticParticleClass
    {
        static void Main()
        {
            Console.Title = "CreateChaoticParticleClass";
            Console.SetWindowSize(40, 10);
            Console.BufferWidth = Console.WindowWidth = 40;
            Console.BufferHeight = Console.WindowHeight = 10;      

            Console.WriteLine("Please go to ChaoticParticle.cs \nin the ParticleSystem project.");
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
