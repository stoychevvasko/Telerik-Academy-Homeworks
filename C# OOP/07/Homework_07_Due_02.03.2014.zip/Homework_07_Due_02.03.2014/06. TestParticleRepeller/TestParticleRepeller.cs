﻿/*

<Problem 06>

 Test the ParticleRepeller class through the
 ParticleSystemMain class
 
*/

namespace _06.TestParticleRepeller
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    class TestParticleRepeller
    {
        static void Main()
        {
            Console.Title = "TestParticleRepeller";
            Console.SetWindowSize(40, 10);
            Console.BufferWidth = Console.WindowWidth = 40;
            Console.BufferHeight = Console.WindowHeight = 10;

            Console.WriteLine("Please go to ParticleSystemMain.cs\nin the ParticleSystem project.");
            Console.WriteLine();
            Console.WriteLine();
        }
    }
}
