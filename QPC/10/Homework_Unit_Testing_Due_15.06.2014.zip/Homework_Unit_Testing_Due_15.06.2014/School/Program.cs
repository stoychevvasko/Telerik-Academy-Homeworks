﻿// <copyright file="Program.cs" company="telerikacademy.com">for educational purposes only</copyright>
// <author>my name is Legion for we are many</author>

namespace School
{
    using System;

    /// <summary>Contains the Main() method.</summary>
    public class Program
    {
        /// <summary>Main program logic.</summary>
        public static void Main()
        {
            Console.WriteLine("Student class - 95% coverage");
            Console.WriteLine("Course class - 100% coverage");
            Console.WriteLine("School class - 100% coverage");
        }
    }
}
